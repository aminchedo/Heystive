"""
Persian Voice Assistant "استیو" (Steve)
Complete Production Implementation
"""

__version__ = "1.0.0"
__author__ = "Steve Voice Assistant Team"
__description__ = "Persian Voice Assistant with Smart Home Integration"