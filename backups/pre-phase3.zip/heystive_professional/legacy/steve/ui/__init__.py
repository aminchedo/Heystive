"""
Steve Voice Assistant - Web Interface Module
Professional web interface for Persian Voice Assistant
"""

from .web_interface import SteveWebInterface

__all__ = ['SteveWebInterface']