# Heystive Integration Module
# Bridge between voice capabilities and existing functionality