# Heystive Voice Module
# Persian TTS and STT capabilities